export interface IWhiteList {
	queryId: string;

}
