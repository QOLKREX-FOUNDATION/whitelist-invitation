export interface  IContent {
    count:number;
}