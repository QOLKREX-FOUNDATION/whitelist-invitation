
export interface IBody {
	queryId: string;
}
