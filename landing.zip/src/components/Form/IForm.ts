export interface IForm {
	form: any;
	handleChangeForm: (e: any) => void;
	onSubmit: (e: any) => void;
}
